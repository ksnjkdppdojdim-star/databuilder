
<div id="login">
    <form name="login" action="/login" method="post">
        <table>
            <tr>
                <td class="left"><label for="uname">{TR_USERNAME}</label></td>
                <td class="right"><input type="text" name="uname" id="uname" value="{UNAME}"></td>
            </tr>
            <tr>
                <td class="left"><label for="password">{TR_PASSWORD}</label></td>
                <td class="right"><input type="password" name="upass" id="password" value=""></td>
            </tr>
            <tr>
                <td colspan="2" class="right">
                    <!-- BDP: lost_password_support -->
                    <a class="link_as_button" href="lostpassword.php">{TR_LOSTPW}</a>
                    <!-- EDP: lost_password_support -->
                    <button type="submit" name="Submit" tabindex="3">{TR_LOGIN}</button>
                </td>
            </tr>
        </table>
    </form>
</div>
