<?php
/**
 * i-MSCP DataBuilderIMSCPV3
 *
 * @author        Jules MAHOUNOU <jtodjinou@datatechnologies.bj>
 * @copyright (C) 2024 Jules MAHOUNOU
 * @license       i-MSCP License <https://www.i-mscp.net/license-agreement.html>
 */

return [
    'name'        => 'DataBuilderIMSCPV3',
    'version'     => '1.3.12',
    'build'       => '2026030202',
    'date'        => '2024-01-01',
    'desc'        => 'Magento-like templating system for i-MSCP - Provides modular theming, layout blocks, and flexible template rendering.',
    'url'         => 'https://github.com/ksnjkdppdojdim-star/databuilder',
    'author'      => 'Jules MAHOUNOU',
    'email'       => 'jtodjinou@datatechnologies.bj',
    'require_api' => '1.5.0'
];
