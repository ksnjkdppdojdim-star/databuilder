<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{TR_PAGE_TITLE}</title>
    <link rel="stylesheet" href="{THEME_ASSETS_PATH}/css/theme.css?v={THEME_ASSETS_VERSION}">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        html, body { height: 100%; }
        body { font-family: Arial, sans-serif; background: #f5f5f5; }
        .layout { display: flex; height: 100vh; }
        .sidebar { width: 250px; background: white; border-right: 1px solid #ddd; overflow-y: auto; padding: 20px; }
        .sidebar h2 { margin-bottom: 20px; }
        .sidebar ul { list-style: none; }
        .sidebar li { margin: 10px 0; }
        .sidebar a { color: #0066cc; text-decoration: none; display: block; padding: 8px; }
        .sidebar a:hover { background: #f0f0f0; }
        .main-content { flex: 1; display: flex; flex-direction: column; }
        .header { background: white; border-bottom: 1px solid #ddd; padding: 20px 30px; }
        .header h1 { margin: 0; }
        .content-wrapper { flex: 1; overflow-y: auto; padding: 20px 30px; }
        .page-content { background: white; padding: 20px; border: 1px solid #ddd; margin-bottom: 20px; }
        .notice { padding: 12px 20px; border-radius: 4px; margin-bottom: 20px; }
        .notice.success { background: #e6f7e6; color: #009900; border: 1px solid #99dd99; }
        .notice.error { background: #ffe6e6; color: #cc0000; border: 1px solid #ff9999; }
        .notice.warning { background: #fff9e6; color: #cc8800; border: 1px solid #ffdd99; }
        .notice.info { background: #e7f3ff; color: #004499; border: 1px solid #b3d9ff; }
        .footer { background: white; border-top: 1px solid #ddd; padding: 15px 30px; text-align: center; font-size: 12px; color: #666; }
    </style>
</head>
<body>
    <div class="layout">
        <!-- BDP: sidebar_block -->
        <aside class="sidebar">
            <h2>i-MSCP</h2>
            <div></div>
        </aside>
        <!-- EDP: sidebar_block -->

        <div class="main-content">
            <!-- BDP: header_block -->
            <div class="header">
                <h1>Control Panel</h1>
            </div>
            <!-- EDP: header_block -->

            <div class="content-wrapper">
                <!-- BDP: page_message -->
                <div id="notice" class="notice {MESSAGE_CLS}">
                    {MESSAGE}
                </div>
                <!-- EDP: page_message -->

                <!-- BDP: page_content -->
                <div class="page-content">
                    {LAYOUT_CONTENT}
                </div>
                <!-- EDP: page_content -->
            </div>

            <!-- BDP: footer_block -->
            <footer class="footer">
                <p>&copy; 2010-2026 i-MSCP. All rights reserved.</p>
            </footer>
            <!-- EDP: footer_block -->
        </div>
    </div>

    <script src="{THEME_ASSETS_PATH}/js/jquery/jquery.js?v={THEME_ASSETS_VERSION}"></script>
    <script src="{THEME_ASSETS_PATH}/js/imscp.min.js?v={THEME_ASSETS_VERSION}"></script>
</body>
</html>

