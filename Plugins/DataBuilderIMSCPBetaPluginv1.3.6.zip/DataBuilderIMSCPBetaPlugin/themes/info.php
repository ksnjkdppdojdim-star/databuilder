<?php
/**
 * DataBuilder Theme Info
 * 
 * This file is required by iMSCP to recognize DataBuilder as a theme
 * The theme is actually managed by the DataBuilderIMSCPBetaPlugin
 */

return [
    'theme_name'    => 'DataBuilder',
    'theme_version' => '1.0.0',
    'theme_author'  => 'Jules MAHOUNOU',
    'theme_desc'    => 'Magento-like modular theming for i-MSCP - Provides flexible theming, module system, and layout management',
    'theme_type'    => 'frontend',
    'theme_default' => false,  // Not set as default theme by default
];

