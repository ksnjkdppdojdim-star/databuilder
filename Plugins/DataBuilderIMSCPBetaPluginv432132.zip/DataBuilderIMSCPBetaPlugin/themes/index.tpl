<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>DataBuilder Theme</title>
</head>
<body>
    <div id="content">
        <!-- DataBuilder content will be injected here -->
        {LAYOUT_CONTENT}
    </div>
</body>
</html>

