<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{TR_PAGE_TITLE}</title>
    
    <!-- iMSCP CSS -->
    <link rel="stylesheet" href="/gui/themes/default/assets/css/{STYLESHEET}">
    
    <!-- DataBuilder CSS -->
    <link rel="stylesheet" href="/gui/plugins/DataBuilderIMSCPBetaPlugin/assets/css/databuilder.css">
    
    {PAGE_MESSAGE}
</head>
<body>
    <div id="header">
        <!-- Navigation will be injected -->
        {NAVIGATION}
    </div>
    
    <div id="main">
        <div class="container">
            <!-- Page messages -->
            {PAGE_MESSAGE}
            
            <!-- Main content -->
            {LAYOUT_CONTENT}
        </div>
    </div>
    
    <div id="footer">
        <!-- Footer content -->
        {FOOTER}
    </div>
    
    <!-- iMSCP JS -->
    <script src="/gui/themes/default/assets/js/{JAVASCRIPT}"></script>
    
    <!-- DataBuilder JS -->
    <script src="/gui/plugins/DataBuilderIMSCPBetaPlugin/assets/js/databuilder.js"></script>
</body>
</html>

